"use strict";

var randomWordArr = [
    "javascript",
    "java",
    "python",
    "csharp",
    "ruby"
];

//choosing a random word
var randomWord = randomWordArr[Math.floor(Math.random() * randomWordArr.length)];

//global variables
var placeHolder; //
var correctAnswers = 0;
var incorrectAnswers = 0;
var maxWrong = 6;
//empty array to store the guesses
var answerArray = [];

//fill in the answer array/dash with under scores
function start() {
    for (var i = 0; i < randomWord.length; i++)
    {
        answerArray[i] = "_";
    }
    //putting them in a string
    placeHolder = answerArray.join(" ");
    document.getElementById("answer").innerHTML = placeHolder;
}

function gettingLetter() {
    //getting the letter from the user that matches the randomly chosen word
    let letter = document.getElementById("letter").value;

    let weFindTheLetter = false;

    //verify that is not empty
    if (letter.length > 0) {
        for (let i = 0; i < randomWord.length; i++) {
            if (randomWord[i] === letter) {
                answerArray[i] = letter;
                weFindTheLetter = true;
                correctAnswers++;
            }
        }
    }
    if (weFindTheLetter === false) {
        incorrectAnswers++;
    }
                                //wrong guesses
    document.getElementById("mistakes").innerHTML = incorrectAnswers;
    document.getElementById("answer").innerHTML = answerArray.join(" ");

    //exhausting maximum chances
    if (incorrectAnswers >= maxWrong) {
        document.getElementById("stat").innerHTML = "You lost!";
    } else if (correctAnswers == randomWordArr.length || correctAnswers == randomWord.length) {
        document.getElementById("stat").innerHTML = "You won! Well done!";
    }
}